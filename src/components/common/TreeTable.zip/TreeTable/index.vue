<template>
  <!-- '$attrs'表示子组件在父作用域中不作为 prop 被识别 (且获取) 的特性绑定 (class 和 style 除外) -->
  <el-table :data="formatData" :row-style="showRow" v-bind="$attrs" row-key="id">
    <!-- 表示children为空的父元素 -->
    <el-table-column v-if="columns.length === 0" width="150">
      <template slot-scope="scope">
        <span v-for="(space, spIndex) in scope.row._level" :key="spIndex+'sp'" class="w_tree_space"></span>
        <span v-if="iconShow(0, scope.row)" class="icon_tree" @click="toggleExpanded(scope.$index)">
          <!-- 默认是'+' -->
          <i v-if="!scope.row._expanded" class="el-icon-plus"></i>
          <i v-else class="el-icon-minus"></i>
        </span>
        {{ space.$rowIndex }}
      </template>
    </el-table-column>
    <el-table-column v-for="(column, index) in columns" v-else :key="column.value" :label="column.text" :width="column.width">
      <template slot-scope="scope">
        <span v-for="space in scope.row._level" :key="space+'sc'" v-if="index === 0" class="w_tree_space"></span>
        <span v-if="iconShow(index, scope.row)" class="icon_tree" @click="toggleExpanded(scope.$index)">
          <i v-if="!scope.row._expanded" class="el-icon-plus"></i>
          <i v-else class="el-icon-minus"></i>
        </span>
        <!-- ??? -->
        {{ scope.row[column.value] }}
      </template>
    </el-table-column>
    <!-- 匿名slot只能作为没有slot属性的元素的插槽 -->
    <slot />
  </el-table>
</template>

<script>
  /**
   * @author: Hilary
   * @Date: 2019/06/10
   */
  import treeToArray from './eval'
  export default {
    name: 'TreeTable',
    props: { /*跳过eslint的检验*/
      /* eslint-disable */
      data: {
        type: [Array, Object],
        required: true
      },
      columns: {
        type: Array,
        defalut: () => []
      },
      evalFunc: Function,
      evalArgs: Array,
      expandAll: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {}
    },
    computed: {
      // 格式化数据源
      formatData: function() {
        let tmp;
        // 判断是否为数组
        if (!Array.isArray(this.data)) {
          temp = [this.data];
        } else {
          tmp = this.data;
        }
        const func = this.evalFunc || treeToArray;
        // ??? evalArgs的值
        const args = this.evalArgs ? Array.concat([tmp, this.expandAll], this.evalArgs) : [tmp, this.expandAll];
        // 存在==============================问题
        let tmp1, agrs;
        [tmp1, ...agrs] = func.apply(null, args);
        return [tmp1]; // 第一个参数与'null'，函数体内的this会默认指向宿主对象，在浏览器环境中，就是window
                                        // apply第二个参数为ArrayLike,(数组或类数组 -- 如对象{'0': '2', '1', '5', 'length': '2'})
      }
    },
    watch: {
      data: {
        handler (nv) {
          console.log(nv);
          this.data = nv
        },
        deep: true,
        immediate: false
      }
    },
    methods: {
      // 行的style的回调函数
      showRow: function (row) {
        const show = (row.row.parent ? (row.row.parent._expanded && row.row.parent._show) : true );
        row.row._show = show;
        return show ? 'animation:treeTableShow 1s;-webkit-animation:treeTableShow 1s;' : 'display: none';
      },
      // 切换是否展开下级
      toggleExpanded: function (paIndex) {
        const record = this.formatData[paIndex];
        record._expanded = !record._expanded;
      },
      // 是否显示图标
      iconShow: function (index, record) {
        return (index === 0 && record.children && record.children.length > 0);
      }
    }
  }
</script>

<style rel="stylesheet/css">
  @keyframes treeTableShow {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
  @-webkit-keyframes treeTableShow {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
</style>
<style lang="scss" rel="stylesheet/scss" scoped>
  $color-blue: #2196F3;
  $space-width: 18px;
  .w_tree_space {
    position: relative;
    top: 1px;
    display: inline-block;
    font-style: normal;
    font-weight: 400;
    width: $space-width;
    height: 14px;
    &::before {
      content: "";
    }

    table td {
      line-height: 26px;
    }

    .icon_tree {
      position: relative;
      cursor: pointer;
      color: $color-blue;
      margin-left: -$space-width;
    }
  }
</style>
